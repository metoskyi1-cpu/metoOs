package com.metoos.system;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent; // جديد: لاستخدام Intents (نوايا)
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_main); 
        
        Button appsDrawerButton = findViewById(R.id.btn_apps_drawer);
        TextView timeDisplay = findViewById(R.id.time_display);
        
        // وظيفة الضغط على زر قائمة التطبيقات (الزر A)
        appsDrawerButton.setOnClickListener(v -> {
            // كود فتح قائمة التطبيقات (Apps Drawer)
            try {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_HOME); // نطلب فتح الصفحة الرئيسية
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                
            } catch (Exception e) {
                // إذا فشل فتح القائمة
                Toast.makeText(this, "Meto OS Error: Cannot launch Apps List", Toast.LENGTH_LONG).show();
            }
        });

        // تحديث وعرض الوقت الحالي
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a | dd MMM");
            String formattedTime = LocalTime.now().format(formatter);
            timeDisplay.setText(formattedTime);
        } catch (Exception e) {
            timeDisplay.setText("Meto OS Time");
        }
    }
}
